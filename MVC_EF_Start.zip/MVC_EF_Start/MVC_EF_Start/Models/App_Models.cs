﻿
namespace MVC_EF_Start.Models
{
  public class App_Models
  {
  }
}
