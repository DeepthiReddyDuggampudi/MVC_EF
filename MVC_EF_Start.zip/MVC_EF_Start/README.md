# MVC_EF_Start
Created starting point for an MVC Core project with Entity Framework

This is a starting point for an MVC Core project, with tooling for Entity Framework. When run, it will create a database in the local MSSQLServer instance.
